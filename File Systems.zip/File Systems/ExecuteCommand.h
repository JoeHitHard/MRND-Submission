#include "Operations.h"
#define COMMANDSIZE 5
char COMMANDS[10][100] = { "create", "put","get","delete", "foreign" };
int getCommandCode(char *command){
	int i = 0;
	for (i = 0; i < COMMANDSIZE; i++){
		if (strcmp(COMMANDS[i], command) == 0){
			return i;
		}
	}
	return -1;
}
void executeCommand(TS **ts,char *command){
	char tok[100] = "\0";
	char table[100] = "\0";
	sscanf(command, "%s%s", tok,table);
	TN *tn = searchInTS(table,*ts);
	int cc = getCommandCode(tok);
	CH *ch;
	switch (cc){
	case 0:
		if (tn != NULL){
			printf("\nTable Already Exists.");
			return;
		}
		ch=commandCreate(&tn,command);
		(tn)->columnHeader = ch;
		insertIntoTS(tn, *ts);
		break;
	case 1:
		if (tn == NULL){
			printf("\nTable dose not Exists.");
			return;
		}
		commandPut(*ts,tn, command);
		break;
	case 2:
		if (tn == NULL){
			printf("\nTable dose not Exists.");
			return;
		}
		commandGet(tn, command);
		printf("\n");
		break;
	case 3:
		if (tn == NULL){
			printf("\nTable dose not Exists.");
			return;
		}
		commandDelete(tn, command);
		break;
	case 4:
		if (tn == NULL){
			printf("\nTable dose not Exists.");
			return;
		}
		commandForeign(*ts,tn,command);
		break;
	}
	int i = 0;
	return 1;
}
/*
create users (username char 30,mailid char 30,phone char 30,dob char 30);
create usersPosts (username char 30,postids char 30);
foreign usersPosts username users username;
put users (joe,joe,joe@gmail.com,9876543210,22/11/1997);
put usersPosts (joe,joe,p1$p3);
get usersPosts joe;
put usersPosts (jo,jo,p1$p3);
create postids (postid char 30,addressOnDisk char 100);
create followers (username char 30,followers char 100);
put users (joe,joe,joe@gmail.com,9876543210,22/11/1997);
put users (joseph,joseph,joseph@gmail.com,9876543210,22/11/1997);
get users all;
put users (joe,joe,joseph@gmail.com,7643243210,11/11/1997);
get users all;
put users (tjoe,tjoe,tjoseph@gmail.com,t7643243210,t11/11/1997);
get users all;
delete users tjoe;
get users all;
put users (maggi,maggi,maggi@gmail.com,9876543210,22/11/1997);
get users all;
put postids (p1,p1,www.abc.com/images/p1.jpg);
put postids (p2,p2,www.abc.com/images/p2.jpg);
put postids (p3,p3,www.abc.com/images/p3.jpg);
put postids (p4,p4,www.abc.com/images/p4.jpg);
get postids all;
put usersPosts (joe,joe,p1$p3);
put usersPosts (joseph,joseph,p2);
put usersPosts (maggi,maggi,p4);
get usersPosts all;
put followers (joe,joe,joseph$maggi);
put followers (joseph,joseph,joe$maggi);
put followers (maggi,maggi,joseph);
get followers all;
*/