#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void* allocateMomoryBasedOnSizeAndType(int type,int size){
	void *val=NULL;
	switch (type){
	case 0:
		val = malloc(sizeof(int));
		break;
	case 1:
		val = malloc(sizeof(char)*size);
		break;
	case 2:
		val = malloc(sizeof(long int)*size);
		break;
	}
	return val;
}
typedef struct ForeignNode{
	char *tableName;
	int foreignColNumber;
	int currentColNumber;
	struct ForeignNode *nextConstraint;
}FN;

FN* createFN(char *tn, int fcolNum, int curNumber){
	FN *node = (FN*)malloc(sizeof(FN));
	node->currentColNumber = curNumber;
	node->foreignColNumber = fcolNum;
	node->nextConstraint = NULL;
	node->tableName = (char*)malloc(sizeof(char)*strlen(tn) + 5);
	strcpy(node->tableName, tn);
	return node;
}

void insertFN(FN *mainFN, FN *newFN){
	FN *t = mainFN;
	while (t->nextConstraint!=NULL){
		t = t->nextConstraint;
	}
	t->nextConstraint = newFN;
}

typedef struct ColumnNode{
	void *value;
	int type;
	int size;
	int version;
	struct ColumnNode *previousVersion;
}CNode;
CNode* createCNode(int type,int version,int size){
	CNode *node = (CNode*)malloc(sizeof(CNode));
	node->size = size;
	node->value = allocateMomoryBasedOnSizeAndType(type,size);
	node->type = type;
	node->version = version;
	return node;
}
typedef struct Column{
	CNode *value;
	int columNumber;
	struct Column *nextColumn;
}Col;
Col *createCol(int cn){
	Col *node = (Col*)malloc(sizeof(Col));
	node->nextColumn = NULL;
	node->columNumber = cn;
	node->value = NULL;
	return node;
}
void insertCNode(Col *col, CNode *cn){
	CNode *cNode = col->value;
	cn->previousVersion = cNode;
	col->value = cn;
	return;
}

typedef struct ColumnHeader{
	char *columnName;
	int type;
	int size;
	FN *constraints;
	struct ColumnHeader *nextColumn;
}CH;

CH* createCH(char *cn, int type,int size){
	CH *node = (CH*)malloc(sizeof(CH));
	node->columnName = (char*)malloc(sizeof(char)*strlen(cn)+10);
	strcpy(node->columnName, cn);
	node->type = type;
	node->size = size;
	node->constraints = NULL;
	node->nextColumn = NULL;
	return node;
}

void insertIntoCH(CH *ch, CH *newNode){
	if (ch == NULL){
		ch = newNode;
		return;
	}
	while (ch->nextColumn != NULL){
		ch = ch->nextColumn;
	}
	ch->nextColumn = newNode;
	return;
}

typedef struct RowNode{
	char *key;
	int commit;
	int current;
	Col *col;
}RN;

RN* createRN(Col *c,char *key){
	RN *node = (RN*)malloc(sizeof(RN));
	node->col=c;
	node->commit = 0;
	node->current = 0;
	node->key = (char*)malloc(sizeof(char)*strlen(key) + 10);
	strcpy(node->key, key);
	return node;
}

typedef struct TableNode{
	RN **nodes;
	int size;
	int ind;
	CH *columnHeader;
	char *tableName;
}TN;
TN *createTN(char *tname,int size){
	TN *node = (TN*)malloc(sizeof(TN));
	node->nodes = (RN**)malloc(sizeof(RN*)*size);
	node->ind = 0;
	node->size = size;
	node->columnHeader = NULL;
	node->tableName = (char*)malloc(sizeof(char)*strlen(tname) + 10);
	strcpy(node->tableName, tname);
	return node;
}
void insertIntoTN(TN *tn, RN *rn){
	if (tn->ind >= tn->size - 1){
		tn->size = tn->size * 2;
		tn->nodes = (RN**)realloc(tn->nodes,sizeof(RN*)*tn->size);
	}
	tn->nodes[tn->ind] = rn;
	tn->ind = tn->ind + 1;
	return;
}
RN* searchKeyInTN(TN *tn, char*key){
	RN **r = tn->nodes;
	int i = 0;
	for (i = 0; i < tn->ind; i++){
		if (strcmp(r[i]->key, key) == 0){
			return r[i];
		}
	}
	return NULL;
}

void printCNode(CNode *c, int commit){
	CNode *t = c;
	while (t->version > commit){
		t=t->previousVersion;
	}
	int i = 0;
	int *di=NULL;
	char *dc=NULL;
	long int *dl = NULL;
	void *v=t->value;
	switch (t->type){
	case 0:
		di = (int*)v;
		for (i = 0; i < t->size; i++){
			printf("%d", di[i]);
		}
		printf("|");
		break;
	case 1:
		dc = (int*)v;
		printf("%15s|", dc);
		break;
	case 2:
		dl = (int*)v;
		for (i = 0; i < t->size; i++){
			printf("%d", dl[i]);
		}
		printf("|");
		break;
	}
}

void displayRN(RN *r){
	if (r == NULL){
		return;
	}
	printf("\n");
	if (r != NULL){
		Col *t = r->col;
		while (t != NULL){
			printCNode(t->value,r->commit);
			t=t->nextColumn;
		}
	}
	return;
}
void insertIntoRN(RN *r, Col *col){
	Col *t = r->col;
	while (t != NULL){
		if (t->columNumber == col->columNumber){
			CNode *c1 = t->value;
			CNode *c2 = col->value;
			c2->previousVersion = c1;
			c1->previousVersion;
			t->value = c2;
		}
		t = t->nextColumn;
		col=col->nextColumn;
	}
	return;
}
typedef struct Tables{
	TN **nodes;
	int size;
	int ind;
}TS;
TS* createTS(int size){
	TS *node = (TS*)malloc(sizeof(TS));
	node->ind = 0;
	node->size = size;
	node->nodes = (TN**)malloc(sizeof(TN*)*size);
	return node;
}
void insertIntoTS(TN* tn,TS* ts){
	if (ts->ind >= ts->size - 2){
		ts->size = ts->size * 2;
		ts->nodes = (TN**)realloc(ts->nodes,sizeof(TN*)*ts->size);
	}
	ts->nodes[ts->ind] = tn;
	ts->ind = ts->ind + 1;
	return;
}

TN** searchInTS(char *tn, TS *ts){
	if (ts == NULL){
		return NULL;
	}
	int i = 0;
	for (i = 0; i < ts->ind; i++){
		TN *t = ts->nodes[i];
		if (strcmp(tn, t->tableName) == 0){
			return t;
		}
	}
	return NULL;
}