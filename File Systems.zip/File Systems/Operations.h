#include "Structures.h"
#define TYPESIZE 3
char TYPE[10][20] = {"int","char","lint"};
char *removePart(char *c, int i){
	int j = 0;
	char *ret = (char*)malloc(sizeof(char)*strlen(c) + 5 - i);
	while (c[j + i] != '\0'){
		ret[j] = c[i + j];
		j++;
	}
	ret[j] = '\0';
	return ret;
}
char* stringTok(char *t, char dl){
	if (t == NULL){
		return NULL;
	}
	char *ret = (char*)malloc(sizeof(char)*strlen(t) + 5);
	int i = 0;
	while (t[i] != '\0'&&t[i] != dl){
		ret[i] = t[i];
		i++;
	}
	ret[i] = '\0';
	return ret;
}
int getTypeCode(char *type){
	char c[100] = "\0";
	strcpy(c, type);
	char *t;
	t = stringTok(type, ' ');
	type = removePart(type, strlen(t) + 1);
	int i = 0;
	for (i = 0; i < TYPESIZE; i++){
		if (strcmp(TYPE[i], t) == 0){
			return i;
		}
	}
	return -1;
}

CH* addColumn(char *tok){
	CH *ch=NULL;
	char *ct = (char*)malloc(sizeof(char)*strlen(tok) + 5);
	strcpy(ct, tok);
	char c[50] = "\0";
	char c1[50] = "\0";
	char ty[50] = "\0";
	char *t;
	int id;
	int size = 1;
	t = stringTok(ct, ',');
	ct = removePart(ct, strlen(t)+1);
	while (t != NULL){
		if (strcmp(t, ")") == 0){
			return ch;
		}
		if (t[strlen(t) - 1] == ')'){
			t[strlen(t) - 1] = '\0';
			sscanf(t, "%s%s%d", c, ty,&size);
			id = getTypeCode(ty);
			CH *chnode = createCH(c, id,size);
			if (ch == NULL){
				ch = chnode;
				return ch;
			}
			insertIntoCH(ch, chnode);
			return ch;
		}
		sscanf(t, "%s%s%d", c, ty, &size);
		id = getTypeCode(ty);
		CH *chnode = createCH(c, id, size);
		if (ch == NULL){
			ch = chnode;
			t = stringTok(ct, ',');
			ct = removePart(ct, strlen(t)+1);
			continue;
		}
		insertIntoCH(ch, chnode);
		t = stringTok(ct, ',');
		ct = removePart(ct, strlen(t)+1);
	}
	return ch;
}
CH* commandCreate(TN **tn,char *command){
	int i = 0;
	char *t;
	char c[50]="\0";
	char c1[50] = "\0";
	t = stringTok(command, ' ');
	command = removePart(command, strlen(t) + 1);
	t = stringTok(command, ' ');
	strcpy(c1, t);
	command = removePart(command, strlen(t) + 1);
	c[0] = '\0';
	strcpy(c, t);
	t = stringTok(command, '(');
	command = removePart(command, strlen(t) + 1);
	CH *ch = addColumn(command);
	*tn = createTN(c1, 32);
	return ch;
}

int positionOfChar(char *c, char d){
	int i = 0;
	while (c[i] != '\0'){
		if (c[i] == d){
			return i;
		}
		i++;
	}
	return -1;
}

void readByType(int type, char *c,void *v,int size){
	int i = 0;
	int k = 0;
	switch (type){
	case 0:
		for (i = 0; i < size; i++){
			sscanf(c, "%d$", (((int*)v)+(i*sizeof(int))));
			int j = positionOfChar(c, '$');
			if (j == -1){
				return;
			}
			c = removePart(c, j + 1);
		}
		break;
	case 1:
		k = strlen(c);
		if (k > size - 1){
			return;
		}
		for (i = 0; i < k; i++){
			*(((char*)v) + (i*sizeof(char))) = c[i];
		}
		*(((char*)v) + (i*sizeof(char))) = '\0';
		break;
	case 2:
		for (i = 0; i < size; i++){
			sscanf(c, "%d$", (((long int*)v) + (i*sizeof(long int))));
			int j = positionOfChar(c, '$');
			if (j == -1){
				return;
			}
			c = removePart(c, j + 1);
		}
	}
}

int compareByType(void *v1,void *v2, int size){
	int i = 0;
	for (i = 0; i < size; i++){
		if (*(((int*)v1) + (i*sizeof(int))) == *(((int*)v2) + (i*sizeof(int)))){
			return 1;
		}
	}
	return -1;
}


int checkConstraints(TS *ts,FN *fn, int i, CNode *cn){
	if (fn == NULL){
		return 1;
	}
	FN *t = fn;
	while (t != NULL){
		if (t->currentColNumber == i){
			TN *tn = searchInTS(t->tableName, ts);
			if (tn == NULL){
				return -1;
			}
			for (i = 0; i < tn->ind; i++){
				RN *r = tn->nodes[i];
				if (r == NULL){
					return -1;
				}
				Col *c = r->col;
				if (c == NULL){
					return -1;
				}
				Col *tc = c;
				while (tc != NULL){
					if (tc->columNumber == i){
						CNode *tcn = tc->value;
						if (tcn == NULL){
							return -1;
						}
						if (compareByType(cn->value, tcn->value, cn->size) == 1){
							return 1;
						}
						else{
							return -1;
						}
					}
					tc = tc->nextColumn;
				}
			}
		}
		t = t->nextConstraint;
	}
	return 1;
}


Col* addRow(TS *ts,char *tok,CH *c,int current){
	CH *t = c;
	FN *fn = c->constraints;
	Col*head=NULL;
	char *ct = (char*)malloc(sizeof(char)*strlen(tok) + 5);
	strcpy(ct, tok);
	Col *col =head;
	char *k;
	k = stringTok(ct, ',');
	ct = removePart(ct, strlen(k) + 1);
	CNode *cn;
	int i = -1;
	while (t != NULL&&k!=NULL){
		i++;
		if (k[strlen(k) - 1] == ')'){
			k[strlen(k) - 1] = '\0';
			cn = createCNode(t->type, current, t->size);
			readByType(t->type, k, cn->value,t->size);
			if (col == NULL){
				int check = checkConstraints(ts,fn, i,cn);
				if (check == -1){
					return NULL;
				}
				col = createCol(i);
				col->value = cn;
				col->nextColumn = NULL;
				head = col;
				k = stringTok(ct, ',');
				ct = removePart(ct, strlen(k) + 1);
				t = t->nextColumn;
				continue;
			}
			int check = checkConstraints(ts, fn, i, cn);
			if (check == -1){
				return NULL;
			}
			Col *tempcol = createCol(i);
			tempcol->nextColumn = NULL;
			tempcol->value = cn;
			col->nextColumn = tempcol;
			col = col->nextColumn;
			return head;
		}
		cn = createCNode(t->type, current, t->size);
		readByType(t->type, k, cn->value, t->size);
		int check = checkConstraints(ts,fn, i, cn);
		if (check == -1){
			return NULL;
		}
		if (col == NULL){
			col = createCol(i);
			col->value = cn;
			col->nextColumn = NULL;
			head = col;
			k = stringTok(ct, ',');
			ct = removePart(ct, strlen(k) + 1);
			t = t->nextColumn;
			continue;
		}
		Col *tempcol = createCol(i);
		tempcol->nextColumn = NULL;
		tempcol->value = cn;
		col->nextColumn = tempcol;
		col = col->nextColumn;
		k = stringTok(ct, ',');
		ct = removePart(ct, strlen(k) + 1);
		t = t->nextColumn;
	}
	return head;
}

void updateRow(Col *des, Col *sou){
	Col *t = des;
	while (t != NULL){
		if (t->columNumber == sou->columNumber){
			if (sou->value != NULL){
				t->value = sou->value;
			}
		}
		t = t->nextColumn;
		sou = sou->nextColumn;
	}
	return;
}

void commandPut(TS *ts, TN *t, char *command){
	int i = 0;
	char *tok;
	char *ct = (char*)malloc(sizeof(char)*strlen(command) + 5);
	strcpy(ct, command);
	char c[50] = "\0";
	char c1[50] = "\0";
	char c2[50] = "\0";
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	tok = stringTok(ct, '(');
	ct = removePart(ct, strlen(tok) + 1);
	strcpy(c1, tok);
	if (c1[strlen(c1) - 1] == ' ')
		c1[strlen(c1) - 1] = '\0';
	if (strcmp(c1, t->tableName) != 0){
		return;
	}
	tok = stringTok(ct, ',');
	ct = removePart(ct, strlen(tok) + 1);
	c[0] = '\0';
	strcpy(c, tok);
	if (tok == NULL){
		printf("\nEnter Valid Put Command.");
		return;
	}
	tok = stringTok(ct, ';');
	ct = removePart(ct, strlen(tok) + 1);
	c1[0] = '\0';
	strcpy(c1, tok);
	RN *r=searchKeyInTN(t,c);
	Col *col = NULL;
	if (r == NULL){
		col= addRow(ts,c1, t->columnHeader,1);
		if (col == NULL){
			return;
		}
		RN *r = createRN(col, c);
		r->current = 1;
		insertIntoTN(t, r);
		r->commit = r->current;
		return;
	}
	if (r->commit - 2 >= r->current){
		return;
	}
	r->current = r->current + 1;
	col = addRow(ts,c1, t->columnHeader, r->current);
	updateRow(r->col, col);
	r->commit = r->current;
	return;
}


void stringCopy(char *d, char *s){
	int i = 0;
	while (s[i] != '\0'){
		d[i] = s[i];
		i++;
	}
	d[i] = '\0';
	return;
}

RN* commandGet(TN *t, char *command){
	int i = 0;
	char *tok;
	RN *r = NULL;
	CH *ch;
	char *ct = (char*)malloc(sizeof(char)*strlen(command) + 5);
	stringCopy(ct, command);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	if (strcmp(t->tableName, tok)!= 0){
		printf("\nInvalid Table Name %s.",tok);
		return;
	}
	tok = stringTok(ct, ';');
	ct = removePart(ct, strlen(tok) + 1);
	if (strcmp(tok, "all") == 0){
		ch = t->columnHeader;
		while (ch != NULL){
			printf("%15s|", ch->columnName);
			ch = ch->nextColumn;
		}
		for (i = 0; i < t->ind; i++){
			displayRN(t->nodes[i]);
		}
		return;
	}
	r = searchKeyInTN(t, tok);
	ch = t->columnHeader;
	while (ch != NULL){
		printf("%15s|", ch->columnName);
		ch = ch->nextColumn;
	}
	displayRN(r);
	return r;
}

void commandDelete(TN *t, char *command){
	int i = 0;
	char *tok;
	char *ct = (char*)malloc(sizeof(char)*strlen(command) + 5);
	stringCopy(ct, command);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	if (strcmp(t->tableName, tok) != 0){
		printf("\nInvalid Table Name %s.", tok);
		return;
	}
	tok = stringTok(ct, ';');
	ct = removePart(ct, strlen(tok) + 1);
	RN **r = t->nodes;
	int j = 0;
	for (i = 0; i < t->ind; i++){
		if (strcmp(r[i]->key, tok) == 0){
			if (t->ind == 1){
				t->ind = 0;
				return;
			}
			for (j = i; j < t->ind-1; j++){
				r[j] = r[j + 1];
			}
			t->ind = t->ind - 1;
		}
	}
	return;
}


void commandForeign(TS *ts ,TN *tn, char *command){
	char *tok;
	char tabn[30] = "\0";
	CH *c = tn->columnHeader;
	char *ct = (char*)malloc(sizeof(char)*strlen(command) + 5);
	stringCopy(ct, command);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	if (strcmp(tn->tableName, tok) != 0){
		return;
	}
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	int hj = 0;
	while (c!=NULL&&strcmp(c->columnName, tok) != 0){
		c = c->nextColumn;
		hj = hj + 1;
	}
	tok = stringTok(ct, ' ');
	strcpy(tabn, tok);
	ct = removePart(ct, strlen(tok) + 1);
	int fcn = 1;
	TN *tnn = searchInTS(tabn, ts);
	if (tnn == NULL){
		return;
	}
	tok = stringTok(ct, ' ');
	ct = removePart(ct, strlen(tok) + 1);
	CH *cc = tnn->columnHeader;
	int jk = -1;
	while (cc != NULL){
		jk = jk + 1;
		if (strcmp(cc->columnName, tok) == 0){
			fcn = jk;
			break;
		}
		
	}
	FN *f = createFN(tabn,fcn,hj);
	if (c->constraints == NULL){
		c->constraints = f;
		printf("\nUpdated Constraint.");
		return;
	}
	insertFN(c->constraints, f);
	printf("\nUpdated Constraint.");
	return;
}